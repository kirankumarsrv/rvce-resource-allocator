import com.rvce.scas.scheduler.algorithm.SchedulerResult;
import com.rvce.scas.scheduler.algorithm.TimetableScheduler;
import com.rvce.scas.scheduler.dto.DepartmentInput;

    @Service
public class SchedulerService {

    public SchedulerResult generate(DepartmentInput input) {
        TimetableScheduler scheduler = new TimetableScheduler(input);
        return scheduler.schedule();
    }
}

