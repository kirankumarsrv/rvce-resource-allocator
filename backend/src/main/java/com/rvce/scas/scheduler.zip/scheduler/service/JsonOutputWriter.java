package com.rvce.scas.scheduler.service;

import com.rvce.scas.scheduler.algorithm.SchedulerResult;
import com.rvce.scas.scheduler.model.ScheduledSlot;
import com.rvce.scas.scheduler.model.Subject;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Writes scheduler result to valid JSON.
 * FIX: removed trailing comma bug in unscheduledHours block.
 * In production Spring Boot, replace this with Jackson ObjectMapper.
 */
public class JsonOutputWriter {

    public static void write(SchedulerResult result, String outputPath) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"status\": \"").append(result.isFullyScheduled() ? "COMPLETE" : "PARTIAL").append("\",\n");
        sb.append("  \"totalSlotsAssigned\": ").append(result.getScheduledSlots().size()).append(",\n");

        // Teacher load
        sb.append("  \"teacherLoad\": {\n");
        List<Map.Entry<String,Integer>> loads = result.getTeacherLoadSummary().entrySet().stream().toList();
        for (int i = 0; i < loads.size(); i++) {
            sb.append("    \"").append(loads.get(i).getKey()).append("\": ").append(loads.get(i).getValue());
            if (i < loads.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("  },\n");

        // Unscheduled hours — only subjects with gaps
        sb.append("  \"unscheduledHours\": {\n");
        List<Map.Entry<String,Integer>> unscheduled = result.getUnscheduledHours().entrySet().stream()
            .filter(e -> e.getValue() > 0).toList();
        for (int i = 0; i < unscheduled.size(); i++) {
            sb.append("    \"").append(unscheduled.get(i).getKey()).append("\": ").append(unscheduled.get(i).getValue());
            if (i < unscheduled.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("  },\n");

        // Timetable grid — group by section then day for easy reading
        sb.append("  \"slots\": [\n");
        List<ScheduledSlot> slots = result.getScheduledSlots();
        for (int i = 0; i < slots.size(); i++) {
            ScheduledSlot s = slots.get(i);
            boolean isLab = s.getSubject().getType() == Subject.Type.LAB || s.isLabSecondHour();
            sb.append("    {\n")
              .append("      \"subject\": \"").append(esc(s.getSubject().getName())).append("\",\n")
              .append("      \"subjectId\": \"").append(s.getSubject().getId()).append("\",\n")
              .append("      \"section\": \"").append(s.getSubject().getSectionKey()).append("\",\n")
              .append("      \"year\": ").append(s.getSubject().getYear()).append(",\n")
              .append("      \"teacher\": \"").append(s.getSubject().getTeacherId()).append("\",\n")
              .append("      \"day\": \"").append(s.getDay()).append("\",\n")
              .append("      \"time\": \"").append(s.getTimeSlot().getDisplay()).append("\",\n")
              .append("      \"room\": \"").append(s.getRoom().getId()).append("\",\n")
              .append("      \"isLab\": ").append(isLab).append(",\n")
              .append("      \"isLabSecondHour\": ").append(s.isLabSecondHour()).append("\n")
              .append("    }").append(i < slots.size() - 1 ? "," : "").append("\n");
        }
        sb.append("  ]\n}");

        try (FileWriter fw = new FileWriter(outputPath)) {
            fw.write(sb.toString());
        }
        System.out.println("Output written to: " + outputPath);
    }

    private static String esc(String s) {
        return s.replace("\"", "\\\"");
    }
}
