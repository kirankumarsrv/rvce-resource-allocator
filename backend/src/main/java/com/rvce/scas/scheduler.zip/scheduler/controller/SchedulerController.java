@RestController
@RequestMapping("/api/scheduler")
public class SchedulerController {

    private final SchedulerService schedulerService;

    public SchedulerController(SchedulerService schedulerService) {
        this.schedulerService = schedulerService;  // constructor injection
    }

    @PostMapping("/generate")
    public ResponseEntity<SchedulerResult> generate(@RequestBody DepartmentInput input) {
        SchedulerResult result = schedulerService.generate(input);
        return ResponseEntity.ok(result);
    }
}
